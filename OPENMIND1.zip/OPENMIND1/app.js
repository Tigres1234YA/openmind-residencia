// ============================
// SISTEMA DE USUARIOS
// ============================
const USERS_KEY = 'openmind_users';

function getUsers() {
    const users = localStorage.getItem(USERS_KEY);
    return users ? JSON.parse(users) : {};
}

function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function registerUser(username, email, password) {
    const users = getUsers();
    
    if (users[email]) {
        return { success: false, message: 'El email ya está registrado' };
    }
    
    users[email] = {
        username,
        email,
        password: btoa(password),
        createdAt: new Date().toISOString(),
        progress: {
            stars: 0,
            badges: [],
            streak: 0,
            attempts: 0,
            successes: 0,
            lastActivity: null,
            customPictograms: [],
            customRoutines: [],
            calendar: {}
        }
    };
    
    saveUsers(users);
    return { success: true, message: 'Usuario registrado exitosamente' };
}

function loginUser(email, password) {
    const users = getUsers();
    const user = users[email];
    
    if (!user) {
        return { success: false, message: 'Usuario no encontrado' };
    }
    
    if (atob(user.password) !== password) {
        return { success: false, message: 'Contraseña incorrecta' };
    }
    
    localStorage.setItem('current_user', JSON.stringify({
        email: user.email,
        username: user.username,
        progress: user.progress
    }));
    
    return { success: true, message: 'Inicio de sesión exitoso', user };
}

function getCurrentUser() {
    const user = localStorage.getItem('current_user');
    return user ? JSON.parse(user) : null;
}

function logoutUser() {
    localStorage.removeItem('current_user');
}

function updateUserProgress(email, newProgress) {
    const users = getUsers();
    if (users[email]) {
        users[email].progress = { ...users[email].progress, ...newProgress };
        saveUsers(users);
        
        const currentUser = getCurrentUser();
        if (currentUser && currentUser.email === email) {
            currentUser.progress = users[email].progress;
            localStorage.setItem('current_user', JSON.stringify(currentUser));
        }
        return true;
    }
    return false;
}

// ============================
// DATOS POR DEFECTO
// ============================
const DEFAULT_PICTOGRAMS = [
    { id: 'p1', emoji: '💧', label: 'Agua', speech: 'Tengo sed, por favor dame agua', category: 'necesidades' },
    { id: 'p2', emoji: '🍎', label: 'Comida', speech: 'Tengo hambre, quiero comer algo rico', category: 'necesidades' },
    { id: 'p3', emoji: '🚽', label: 'Baño', speech: 'Necesito ir al baño rápidamente', category: 'necesidades' },
    { id: 'p4', emoji: '🧸', label: 'Jugar', speech: 'Quiero jugar un momento con mis juguetes', category: 'actividades' },
    { id: 'p5', emoji: '🛌', label: 'Descanso', speech: 'Me siento cansado, quiero descansar un momento', category: 'actividades' },
    { id: 'p6', emoji: '🧥', label: 'Abrigo', speech: 'Tengo frío, ¿me pones mi abrigo?', category: 'necesidades' },
    { id: 'p7', emoji: '😊', label: 'Feliz', speech: 'Me siento muy feliz y tranquilo', category: 'emociones' },
    { id: 'p8', emoji: '😢', label: 'Triste', speech: 'Me siento un poco triste', category: 'emociones' },
    { id: 'p9', emoji: '🎨', label: 'Pintar', speech: 'Quiero pintar y dibujar con mis colores', category: 'actividades' },
    { id: 'p10', emoji: '🎵', label: 'Música', speech: 'Quiero escuchar música tranquila', category: 'actividades' },
    { id: 'p11', emoji: '👋', label: 'Hola', speech: 'Hola a todos, buenos días', category: 'emociones' },
    { id: 'p12', emoji: '🩹', label: 'Dolor', speech: 'Me duele algo, por favor ayúdame', category: 'emociones' }
];

const DEFAULT_ROUTINES = [
    { id: 'r1', emoji: '🏫', title: 'Llegar a la escuela o taller', done: false },
    { id: 'r2', emoji: '🎒', title: 'Guardar la mochila en su lugar', done: false },
    { id: 'r3', emoji: '📚', title: 'Completar actividades en clase', done: false },
    { id: 'r4', emoji: '🥪', title: 'Comer el almuerzo', done: false },
    { id: 'r5', emoji: '🦷', title: 'Lavar mis dientes después de comer', done: false },
    { id: 'r6', emoji: '👋', title: 'Despedirme de mis amigos', done: false }
];

const GAME_ITEMS = [
    { id: 'g1', emoji: '🍎', name: 'Manzana' },
    { id: 'g2', emoji: '🐕', name: 'Perro' },
    { id: 'g3', emoji: '🚗', name: 'Auto' },
    { id: 'g4', emoji: '⚽', name: 'Pelota' },
    { id: 'g5', emoji: '🐱', name: 'Gato' },
    { id: 'g6', emoji: '✏️', name: 'Lápiz' },
    { id: 'g7', emoji: '🏠', name: 'Casa' },
    { id: 'g8', emoji: '🍌', name: 'Plátano' }
];

const DIFFICULTY_LEVELS = {
    easy: { options: 3, timeout: 5000, label: 'Fácil' },
    medium: { options: 4, timeout: 3000, label: 'Medio' },
    hard: { options: 5, timeout: 2000, label: 'Difícil' }
};

const BADGE_DEFINITIONS = [
    { id: 'first_star', label: '⭐ Primera Estrella', description: 'Ganaste tu primera estrella' },
    { id: 'five_stars', label: '🌟 5 Estrellas', description: 'Has ganado 5 estrellas' },
    { id: 'ten_stars', label: '💫 10 Estrellas', description: '¡Eres una estrella brillante!' },
    { id: 'first_task', label: '✅ Primera Tarea', description: 'Completaste tu primera tarea del día' },
    { id: 'all_tasks', label: '🏆 Todas las Tareas', description: 'Completaste todas las tareas del día' },
    { id: 'game_master', label: '🎮 Maestro del Juego', description: 'Ganaste 5 juegos seguidos' },
    { id: 'streak_3', label: '🔥 Racha de 3 días', description: '3 días seguidos usando la app' },
    { id: 'streak_7', label: '🔥 Racha de 7 días', description: '¡Una semana completa!' }
];

// ============================
// ESTADO DE LA APLICACIÓN
// ============================
let appState = {
    currentUser: null,
    currentTab: 'speech',
    pictograms: [],
    routines: [],
    voiceRate: 0.8,
    voicePitch: 1.0,
    selectedVoice: null,
    stats: {
        attempts: 0,
        successes: 0
    },
    rewards: {
        stars: 0,
        badges: [],
        streak: 0,
        lastActivity: null
    },
    calendar: {},
    darkMode: false,
    timer: {
        running: false,
        time: 300,
        interval: null
    },
    gameDifficulty: 'easy',
    role: 'child',
    isLocked: false,
    currentCategoryFilter: 'all',
    gameWinsStreak: 0
};

// ============================
// CONSTRUCTOR DE FRASES - MANTIENE EL ORDEN
// ============================
let phraseBuilder = [];
let helpShownThisSession = false;
let confirmCallback = null;
let currentVoiceList = [];

// ============================
// INICIALIZACIÓN PRINCIPAL
// ============================
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = getCurrentUser();
    
    if (currentUser) {
        appState.currentUser = currentUser;
        showUserInterface();
        loadUserData();
    } else {
        showLoginInterface();
    }
    
    setupEventListeners();
    
    // Inicializar Lucide icons
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
    
    initTimer();
    loadVoices();
    
    const firstTime = !localStorage.getItem('openmind_first_time');
    if (firstTime) {
        localStorage.setItem('openmind_first_time', 'false');
        setTimeout(() => {
            showHelp(appState.currentTab, true);
        }, 1000);
    }
});

// ============================
// INTERFAZ DE USUARIO
// ============================
function showLoginInterface() {
    const loginModal = document.getElementById('login-modal');
    const userHeader = document.getElementById('user-header');
    const navStudent = document.getElementById('nav-student');
    const appContent = document.getElementById('app-content');
    
    if (loginModal) loginModal.classList.remove('hidden');
    if (userHeader) userHeader.classList.add('hidden');
    if (navStudent) navStudent.classList.add('hidden');
    if (appContent) appContent.classList.add('blurred');
}

function showUserInterface() {
    const loginModal = document.getElementById('login-modal');
    const userHeader = document.getElementById('user-header');
    const navStudent = document.getElementById('nav-student');
    const appContent = document.getElementById('app-content');
    
    if (loginModal) loginModal.classList.add('hidden');
    if (userHeader) userHeader.classList.remove('hidden');
    if (navStudent) navStudent.classList.remove('hidden');
    if (appContent) appContent.classList.remove('blurred');
    
    if (appState.currentUser) {
        const userName = document.getElementById('user-name');
        if (userName) userName.textContent = appState.currentUser.username;
        
        const avatar = document.getElementById('user-avatar');
        if (avatar) avatar.textContent = '👤';
        
        updateHeaderStars();
    }
    
    switchTab('speech');
}

function loadUserData() {
    const userProgress = appState.currentUser?.progress || {};
    
    const customPictos = userProgress.customPictograms || [];
    appState.pictograms = [...DEFAULT_PICTOGRAMS, ...customPictos];
    
    const customRoutines = userProgress.customRoutines || [];
    appState.routines = [...DEFAULT_ROUTINES, ...customRoutines];
    
    appState.stats = {
        attempts: userProgress.attempts || 0,
        successes: userProgress.successes || 0
    };
    
    appState.rewards = {
        stars: userProgress.stars || 0,
        badges: userProgress.badges || [],
        streak: userProgress.streak || 0,
        lastActivity: userProgress.lastActivity || null
    };
    
    appState.calendar = userProgress.calendar || {};
    appState.gameWinsStreak = userProgress.gameWinsStreak || 0;
    
    renderAll();
}

function updateHeaderStars() {
    const headerStars = document.getElementById('header-stars');
    if (headerStars) headerStars.textContent = appState.rewards.stars || 0;
}

// ============================
// FUNCIONES DE LOGIN/REGISTER
// ============================
function setupLoginEvents() {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('login-email').value;
            const password = document.getElementById('login-password').value;
            
            const result = loginUser(email, password);
            if (result.success) {
                appState.currentUser = getCurrentUser();
                showUserInterface();
                loadUserData();
                showToast('✅ ' + result.message);
                launchConfetti();
            } else {
                showToast('❌ ' + result.message);
            }
        });
    }
    
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('register-username').value;
            const email = document.getElementById('register-email').value;
            const password = document.getElementById('register-password').value;
            
            const result = registerUser(username, email, password);
            if (result.success) {
                document.getElementById('register-form').classList.add('hidden');
                document.getElementById('login-form').classList.remove('hidden');
                document.getElementById('login-subtitle').textContent = '¡Registro exitoso! Inicia sesión';
                document.getElementById('login-email').value = email;
                document.getElementById('login-password').value = password;
                showToast('✅ ' + result.message);
            } else {
                showToast('❌ ' + result.message);
            }
        });
    }
    
    const showRegisterBtn = document.getElementById('btn-show-register');
    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', function() {
            document.getElementById('login-form').classList.add('hidden');
            document.getElementById('register-form').classList.remove('hidden');
            document.getElementById('login-subtitle').textContent = 'Crea tu cuenta';
        });
    }
    
    const showLoginBtn = document.getElementById('btn-show-login');
    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', function() {
            document.getElementById('register-form').classList.add('hidden');
            document.getElementById('login-form').classList.remove('hidden');
            document.getElementById('login-subtitle').textContent = 'Inicia sesión para continuar';
        });
    }
    
    const logoutBtn = document.getElementById('btn-logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            if (appState.isLocked) {
                showToast('🔒 Desbloquea la app primero');
                return;
            }
            showConfirm('Cerrar sesión', '¿Estás seguro de que quieres cerrar sesión?', () => {
                logoutUser();
                appState.currentUser = null;
                showLoginInterface();
                showToast('👋 Sesión cerrada');
            });
        });
    }
}

// ============================
// FUNCIONES DE VOZ
// ============================
function loadVoices() {
    if ('speechSynthesis' in window) {
        const voiceSelect = document.getElementById('voice-select');
        if (!voiceSelect) return;
        
        const loadVoiceList = () => {
            const voices = window.speechSynthesis.getVoices();
            currentVoiceList = voices;
            
            voiceSelect.innerHTML = '<option value="default">Predeterminada</option>';
            const esVoices = voices.filter(v => v.lang.startsWith('es'));
            const otherVoices = voices.filter(v => !v.lang.startsWith('es'));
            
            [...esVoices, ...otherVoices].forEach(voice => {
                const option = document.createElement('option');
                option.value = voice.name;
                option.textContent = `${voice.name} (${voice.lang})`;
                voiceSelect.appendChild(option);
            });
            
            if (appState.selectedVoice) {
                voiceSelect.value = appState.selectedVoice;
            }
        };
        
        if (window.speechSynthesis.getVoices().length > 0) {
            loadVoiceList();
        } else {
            window.speechSynthesis.onvoiceschanged = loadVoiceList;
        }
        
        voiceSelect.addEventListener('change', function() {
            appState.selectedVoice = this.value === 'default' ? null : this.value;
        });
    }
}

function speak(text) {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'es-MX';
        utterance.rate = appState.voiceRate || 0.8;
        utterance.pitch = appState.voicePitch || 1.0;
        
        if (appState.selectedVoice) {
            const voice = currentVoiceList.find(v => v.name === appState.selectedVoice);
            if (voice) utterance.voice = voice;
        } else {
            const voices = window.speechSynthesis.getVoices();
            const esVoice = voices.find(v => v.lang.startsWith('es'));
            if (esVoice) utterance.voice = esVoice;
        }
        
        window.speechSynthesis.speak(utterance);
    }
}

// ============================
// PICTOGRAMAS Y FRASES - ORDEN CORRECTO
// ============================
function renderPictograms() {
    const container = document.getElementById('pictograms-container');
    if (!container) return;
    container.innerHTML = '';
    
    let filteredPictos = appState.pictograms;
    if (appState.currentCategoryFilter !== 'all') {
        filteredPictos = filteredPictos.filter(p => p.category === appState.currentCategoryFilter);
    }
    
    filteredPictos.forEach(picto => {
        const button = document.createElement('button');
        let colorClasses = "bg-amber-50 hover:bg-amber-100 border-amber-200 text-amber-900";
        if (picto.category === 'emociones') {
            colorClasses = "bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-900";
        } else if (picto.category === 'actividades') {
            colorClasses = "bg-emerald-50 hover:bg-emerald-100 border-emerald-200 text-emerald-900";
        }
        
        button.className = `${colorClasses} border-2 rounded-2xl p-4 flex flex-col items-center justify-center gap-2 shadow-sm hover:shadow-md active:scale-95 select-none w-full pictogram-animated`;
        button.onclick = () => selectPicto(picto);
        
        const isImage = picto.imageData && picto.imageData.startsWith('data:image');
        
        button.innerHTML = `
            <span class="text-5xl sm:text-6xl filter drop-shadow select-none">${isImage ? '' : picto.emoji}</span>
            ${isImage ? `<img src="${picto.imageData}" alt="${picto.label}" class="w-16 h-16 object-contain rounded-lg">` : ''}
            <span class="text-sm font-black uppercase tracking-wide mt-1">${picto.label}</span>
            ${picto.isCustom ? '<span class="text-[8px] text-slate-400">✎</span>' : ''}
        `;
        container.appendChild(button);
    });
    
    renderTeacherPictoList();
}

function selectPicto(picto) {
    if (appState.isLocked) {
        showToast('🔒 App bloqueada');
        return;
    }
    
    phraseBuilder.push(picto);
    updatePhraseBuilder();
    
    const display = document.getElementById('phrase-display');
    const clearBtn = document.getElementById('btn-clear-phrase');
    const speakBtn = document.getElementById('btn-speak-phrase');
    
    if (display) {
        const phraseText = phraseBuilder.map(p => p.label).join(' ');
        display.innerText = phraseText || 'Toca una tarjeta para expresarte';
        display.classList.remove('text-blue-800');
        display.classList.add('text-blue-600', 'font-black');
    }
    if (clearBtn) clearBtn.classList.remove('hidden');
    if (speakBtn) speakBtn.classList.remove('hidden');
    
    const fullSpeech = phraseBuilder.map(p => p.speech).join('. ');
    speak(fullSpeech);
    
    giveReward('speech');
}

function updatePhraseBuilder() {
    const container = document.getElementById('phrase-builder');
    if (!container) return;
    
    container.innerHTML = '';
    
    phraseBuilder.forEach((picto, index) => {
        const token = document.createElement('span');
        token.className = 'phrase-token';
        token.innerHTML = `${picto.emoji} ${picto.label}`;
        token.onclick = (e) => {
            e.stopPropagation();
            phraseBuilder.splice(index, 1);
            updatePhraseBuilder();
            
            if (phraseBuilder.length === 0) {
                clearPhrase();
            } else {
                const display = document.getElementById('phrase-display');
                const phraseText = phraseBuilder.map(p => p.label).join(' ');
                display.innerText = phraseText;
            }
        };
        container.appendChild(token);
    });
}

function speakPhrase() {
    if (phraseBuilder.length === 0) {
        showToast('👆 Selecciona al menos una tarjeta');
        return;
    }
    
    const fullSpeech = phraseBuilder.map(p => p.speech).join('. ');
    speak(fullSpeech);
    giveReward('speech');
    showToast('🔊 Frase hablada: ' + phraseBuilder.map(p => p.label).join(' '));
}

function clearPhrase() {
    phraseBuilder = [];
    
    const display = document.getElementById('phrase-display');
    const clearBtn = document.getElementById('btn-clear-phrase');
    const speakBtn = document.getElementById('btn-speak-phrase');
    const builder = document.getElementById('phrase-builder');
    
    if (display) {
        display.innerText = 'Toca una tarjeta para expresarte';
        display.className = 'text-base sm:text-lg font-bold text-blue-800';
    }
    if (clearBtn) clearBtn.classList.add('hidden');
    if (speakBtn) speakBtn.classList.add('hidden');
    if (builder) builder.innerHTML = '';
}

// ============================
// FILTROS DE CATEGORÍA
// ============================
function setupCategoryFilters() {
    document.querySelectorAll('.category-filter').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.category-filter').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            appState.currentCategoryFilter = this.dataset.category;
            renderPictograms();
        });
    });
    const allBtn = document.querySelector('.category-filter[data-category="all"]');
    if (allBtn) allBtn.classList.add('active');
}

// ============================
// RUTINAS
// ============================
function renderRoutines() {
    const container = document.getElementById('routine-container');
    if (!container) return;
    container.innerHTML = '';
    
    appState.routines.forEach((task, idx) => {
        const item = document.createElement('div');
        const isDone = task.done;
        
        item.className = `routine-card flex items-center justify-between p-4 bg-white border-2 rounded-2xl shadow-sm ${
            isDone ? 'completed border-emerald-500 opacity-75' : 'border-slate-200 hover:border-slate-300'
        }`;
        
        item.innerHTML = `
            <div class="flex items-center gap-4">
                <span class="text-3xl filter drop-shadow">${task.emoji}</span>
                <div>
                    <span class="text-[10px] font-bold text-slate-400 block uppercase">Paso ${idx + 1}</span>
                    <p class="text-base font-bold text-slate-700 ${isDone ? 'line-through text-slate-400' : ''}">${task.title}</p>
                </div>
            </div>
            <button class="p-2.5 rounded-xl border-2 font-bold transition active:scale-90 ${
                isDone 
                ? 'bg-emerald-500 border-emerald-500 text-white' 
                : 'bg-white border-slate-300 text-slate-400 hover:text-emerald-600 hover:border-emerald-500'
            }">
                <i data-lucide="${isDone ? 'check' : 'circle'}" class="w-5 h-5"></i>
            </button>
        `;
        
        item.style.cursor = 'pointer';
        item.onclick = () => {
            if (appState.isLocked) {
                showToast('🔒 App bloqueada');
                return;
            }
            toggleRoutineTask(task.id);
        };
        
        container.appendChild(item);
    });
    
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
}

function toggleRoutineTask(id) {
    const index = appState.routines.findIndex(r => r.id === id);
    if (index !== -1) {
        appState.routines[index].done = !appState.routines[index].done;
        renderRoutines();
        renderTeacherRoutines();
        
        if (appState.routines[index].done) {
            speak("¡Excelente! Paso terminado.");
            giveReward('task');
            updateCalendarActivity();
            
            const allDone = appState.routines.every(t => t.done);
            if (allDone) {
                setTimeout(() => {
                    showToast('🎉 ¡Completaste todas las tareas del día!');
                    launchConfetti();
                    checkBadge('all_tasks');
                    giveReward('all_tasks');
                }, 500);
            }
        }
        
        updateProgressUI();
    }
}

function renderTeacherRoutines() {
    const container = document.getElementById('teacher-routine-list');
    if(!container) return;
    container.innerHTML = '';
    
    appState.routines.forEach((task, idx) => {
        const item = document.createElement('div');
        item.className = "flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm";
        item.innerHTML = `
            <div class="flex items-center gap-2">
                <span class="text-xl">${task.emoji}</span>
                <span class="font-bold text-slate-700">${task.title}</span>
                ${task.done ? '<span class="text-xs text-emerald-600 font-bold">✓ Completado</span>' : ''}
                ${task.isCustom ? '<span class="text-xs text-slate-400">✎</span>' : ''}
            </div>
            <div class="flex gap-1">
                <button onclick="window.moveTask(${idx}, -1)" class="p-1 hover:bg-slate-200 text-slate-500 rounded"><i data-lucide="chevron-up" class="w-4 h-4"></i></button>
                <button onclick="window.moveTask(${idx}, 1)" class="p-1 hover:bg-slate-200 text-slate-500 rounded"><i data-lucide="chevron-down" class="w-4 h-4"></i></button>
                <button onclick="window.deleteTask('${task.id}')" class="p-1 hover:bg-red-100 text-red-600 rounded"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
            </div>
        `;
        container.appendChild(item);
    });
    
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
}

function moveTask(index, direction) {
    const targetIdx = index + direction;
    if (targetIdx < 0 || targetIdx >= appState.routines.length) return;
    
    const temp = appState.routines[index];
    appState.routines[index] = appState.routines[targetIdx];
    appState.routines[targetIdx] = temp;
    
    renderRoutines();
    renderTeacherRoutines();
}

function deleteTask(id) {
    showConfirm('Eliminar tarea', '¿Estás seguro de eliminar esta tarea de la rutina?', () => {
        appState.routines = appState.routines.filter(r => r.id !== id);
        renderRoutines();
        renderTeacherRoutines();
        showToast("Actividad eliminada de la rutina.");
        updateProgressUI();
    });
}

// ============================
// JUEGO
// ============================
function initGame() {
    const container = document.getElementById('game-container');
    if(!container) return;
    
    const level = DIFFICULTY_LEVELS[appState.gameDifficulty] || DIFFICULTY_LEVELS.easy;
    const target = GAME_ITEMS[Math.floor(Math.random() * GAME_ITEMS.length)];
    window.currentGameItem = target;
    
    let choices = [target.name];
    const availableItems = GAME_ITEMS.filter(item => item.name !== target.name);
    while (choices.length < level.options) {
        const randomItem = availableItems[Math.floor(Math.random() * availableItems.length)];
        if (!choices.includes(randomItem.name)) {
            choices.push(randomItem.name);
        }
    }
    choices.sort(() => Math.random() - 0.5);
    
    container.innerHTML = `
        <div>
            <span class="bg-amber-100 text-amber-700 font-extrabold text-xs uppercase px-3 py-1.5 rounded-full tracking-wider">Juego de Palabras</span>
            <div class="flex justify-between items-center mt-2">
                <h2 class="text-lg font-bold text-slate-700">¿Cómo se llama esto?</h2>
                <span class="text-xs bg-slate-100 px-2 py-1 rounded-lg">${level.label}</span>
            </div>
        </div>
        
        <div class="flex justify-center my-4">
            <div id="game-card" class="w-40 h-40 bg-slate-50 rounded-2xl border-4 border-slate-200 flex items-center justify-center text-7xl shadow-inner select-none transition-all duration-300">
                ${target.emoji}
            </div>
        </div>
        
        <div id="game-choices" class="grid grid-cols-1 sm:grid-cols-${Math.min(level.options, 3)} gap-3"></div>
        <div id="game-feedback" class="h-8 flex items-center justify-center font-black text-base transition-all duration-300"></div>
        <div class="flex justify-between items-center text-xs text-slate-500">
            <span>Intentos: ${appState.stats.attempts || 0}</span>
            <span>Aciertos: ${appState.stats.successes || 0}</span>
            <span>🏆 Racha: ${appState.gameWinsStreak || 0}</span>
            <button id="btn-difficulty-toggle" class="text-blue-600 hover:text-blue-800 font-bold">Cambiar dificultad</button>
        </div>
    `;
    
    const choicesContainer = container.querySelector('#game-choices');
    choices.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = "bg-white hover:bg-amber-50 text-slate-700 font-bold text-base py-3 px-4 border-2 border-slate-200 rounded-xl shadow-sm hover:border-amber-400 active:scale-95";
        btn.innerText = opt;
        btn.onclick = () => checkGameAnswer(opt, btn);
        choicesContainer.appendChild(btn);
    });
    
    const difficultyBtn = document.getElementById('btn-difficulty-toggle');
    if (difficultyBtn) {
        difficultyBtn.onclick = () => {
            const levels = ['easy', 'medium', 'hard'];
            const currentIndex = levels.indexOf(appState.gameDifficulty);
            const nextIndex = (currentIndex + 1) % levels.length;
            appState.gameDifficulty = levels[nextIndex];
            showToast(`Dificultad cambiada a: ${DIFFICULTY_LEVELS[appState.gameDifficulty].label}`);
            initGame();
        };
    }
    
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
}

function checkGameAnswer(selection, btnElement) {
    if (appState.isLocked) {
        showToast('🔒 App bloqueada');
        return;
    }
    
    const feedback = document.getElementById('game-feedback');
    const gameCard = document.getElementById('game-card');
    
    appState.stats.attempts += 1;
    
    if (selection === window.currentGameItem.name) {
        appState.stats.successes += 1;
        appState.gameWinsStreak += 1;
        feedback.innerHTML = `<span class="text-emerald-600 flex items-center gap-1"><i data-lucide="sparkles" class="w-4 h-4"></i> ¡Excelente! 🎉</span>`;
        gameCard.className = "w-40 h-40 bg-emerald-50 rounded-2xl border-4 border-emerald-500 flex items-center justify-center text-7xl shadow-inner select-none scale-105 transition-all duration-300";
        
        speak("¡Excelente! Es un " + window.currentGameItem.name);
        giveReward('game');
        launchConfetti(5);
        
        if (appState.gameWinsStreak >= 5) {
            checkBadge('game_master');
        }
        
        document.querySelectorAll('#game-choices button').forEach(b => b.disabled = true);
        
        setTimeout(() => {
            initGame();
        }, 2000);
    } else {
        appState.gameWinsStreak = 0;
        feedback.innerHTML = `<span class="text-rose-500 flex items-center gap-1"><i data-lucide="circle-alert" class="w-4 h-4"></i> Inténtalo de nuevo 🌟</span>`;
        gameCard.className = "w-40 h-40 bg-rose-50 rounded-2xl border-4 border-rose-300 flex items-center justify-center text-7xl shadow-inner select-none transition-all duration-300";
        
        speak("Vuelve a intentarlo.");
        btnElement.className = "bg-rose-50 border-rose-300 text-rose-700 font-bold text-base py-3 px-4 border-2 rounded-xl pointer-events-none";
    }
    
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
    updateStatsUI();
    updateProgressUI();
}

// ============================
// SISTEMA DE RECOMPENSAS Y MEDALLAS
// ============================
function giveReward(type) {
    if (!appState.currentUser) return;
    
    const now = new Date();
    const today = now.toDateString();
    
    appState.rewards.stars += 1;
    updateHeaderStars();
    
    if (appState.rewards.stars >= 1) checkBadge('first_star');
    if (appState.rewards.stars >= 5) checkBadge('five_stars');
    if (appState.rewards.stars >= 10) checkBadge('ten_stars');
    
    if (type === 'task') {
        const completedTasks = appState.routines.filter(t => t.done).length;
        if (completedTasks === 1) checkBadge('first_task');
    }
    
    if (appState.rewards.lastActivity !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toDateString();
        
        if (appState.rewards.lastActivity === yesterdayStr) {
            appState.rewards.streak += 1;
        } else {
            appState.rewards.streak = 1;
        }
        appState.rewards.lastActivity = today;
        
        if (appState.rewards.streak >= 3) checkBadge('streak_3');
        if (appState.rewards.streak >= 7) checkBadge('streak_7');
    }
    
    saveProgress();
    updateProgressUI();
}

function checkBadge(badgeId) {
    if (!appState.currentUser) return;
    
    const badge = BADGE_DEFINITIONS.find(b => b.id === badgeId);
    if (!badge) return;
    
    if (!appState.rewards.badges.includes(badgeId)) {
        appState.rewards.badges.push(badgeId);
        showToast(`🏅 ¡Nueva medalla! ${badge.label}`);
        speak(`¡Felicidades! Has ganado la medalla: ${badge.label}`);
        launchConfetti(15);
        saveProgress();
        updateProgressUI();
    }
}

function saveProgress() {
    if (appState.currentUser) {
        updateUserProgress(appState.currentUser.email, {
            stars: appState.rewards.stars,
            badges: appState.rewards.badges,
            streak: appState.rewards.streak,
            lastActivity: appState.rewards.lastActivity,
            attempts: appState.stats.attempts,
            successes: appState.stats.successes,
            calendar: appState.calendar,
            gameWinsStreak: appState.gameWinsStreak,
            customPictograms: appState.pictograms.filter(p => p.isCustom),
            customRoutines: appState.routines.filter(r => r.isCustom)
        });
        appState.currentUser = getCurrentUser();
    }
}

// ============================
// CONFETIS Y CELEBRACIONES
// ============================
function launchConfetti(count = 20) {
    const container = document.createElement('div');
    container.className = 'confetti-container';
    document.body.appendChild(container);
    
    const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ff8800', '#88ff00'];
    
    for (let i = 0; i < count; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = Math.random() * 100 + '%';
        confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.width = (Math.random() * 8 + 4) + 'px';
        confetti.style.height = (Math.random() * 8 + 4) + 'px';
        confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
        confetti.style.animationDuration = (Math.random() * 2 + 2) + 's';
        confetti.style.animationDelay = (Math.random() * 1.5) + 's';
        container.appendChild(confetti);
    }
    
    setTimeout(() => {
        container.remove();
    }, 4000);
}

// ============================
// PROGRESO Y ESTADÍSTICAS
// ============================
function updateStatsUI() {
    const attempts = appState.stats.attempts || 0;
    const successes = appState.stats.successes || 0;
    const accuracy = attempts > 0 ? Math.round((successes / attempts) * 100) : 0;
    
    const attEl = document.getElementById('stat-attempts');
    const accEl = document.getElementById('stat-accuracy');
    const accDisplayEl = document.getElementById('stat-accuracy-display');
    if(attEl) attEl.innerText = attempts;
    if(accEl) accEl.innerText = accuracy + '%';
    if(accDisplayEl) accDisplayEl.innerText = accuracy + '%';
}

function updateProgressUI() {
    const totalTasks = appState.routines.length;
    const completedTasks = appState.routines.filter(t => t.done).length;
    const percentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    
    const progressPercentage = document.getElementById('progress-percentage');
    const progressTasks = document.getElementById('progress-tasks');
    const progressBar = document.getElementById('progress-bar');
    const statStars = document.getElementById('stat-stars');
    const statBadges = document.getElementById('stat-badges');
    const statStreak = document.getElementById('stat-streak');
    
    if (progressPercentage) progressPercentage.textContent = percentage + '%';
    if (progressTasks) progressTasks.textContent = `${completedTasks}/${totalTasks}`;
    if (progressBar) progressBar.style.width = percentage + '%';
    if (statStars) statStars.textContent = appState.rewards.stars || 0;
    if (statBadges) statBadges.textContent = appState.rewards.badges.length || 0;
    if (statStreak) statStreak.textContent = appState.rewards.streak || 0;
    
    updateHeaderStars();
    renderActivityChart();
}

function renderActivityChart() {
    const container = document.getElementById('activity-chart');
    if (!container) return;
    
    container.innerHTML = '';
    const activities = [
        { label: 'Pictogramas', count: appState.stats.attempts || 0, color: 'bg-blue-500' },
        { label: 'Tareas Completadas', count: appState.routines.filter(t => t.done).length, color: 'bg-emerald-500' },
        { label: 'Juegos Ganados', count: appState.stats.successes || 0, color: 'bg-amber-500' },
        { label: 'Estrellas', count: appState.rewards.stars || 0, color: 'bg-yellow-500' },
        { label: 'Medallas', count: appState.rewards.badges.length || 0, color: 'bg-purple-500' }
    ];
    
    const maxCount = Math.max(...activities.map(a => a.count), 1);
    
    activities.forEach(activity => {
        const bar = document.createElement('div');
        const percentage = (activity.count / maxCount) * 100;
        bar.innerHTML = `
            <div class="flex items-center gap-3">
                <span class="text-xs font-bold text-slate-500 w-32 text-right">${activity.label}</span>
                <div class="flex-1 bg-slate-200 rounded-full h-4 overflow-hidden">
                    <div class="${activity.color} h-4 rounded-full transition-all" style="width: ${percentage}%"></div>
                </div>
                <span class="text-xs font-bold text-slate-700 w-8">${activity.count}</span>
            </div>
        `;
        container.appendChild(bar);
    });
}

// ============================
// CALENDARIO
// ============================
function updateCalendar() {
    const now = new Date();
    const month = now.getMonth();
    const year = now.getFullYear();
    renderCalendarMonth(month, year);
}

function renderCalendarMonth(month, year) {
    const grid = document.getElementById('calendar-grid');
    const monthName = document.getElementById('current-month');
    
    if (!grid || !monthName) return;
    
    const monthNames = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    monthName.textContent = `${monthNames[month]} ${year}`;
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startDay = firstDay.getDay();
    
    grid.innerHTML = '';
    
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    for (let i = startDay - 1; i >= 0; i--) {
        const day = document.createElement('div');
        day.className = 'calendar-day other-month';
        day.textContent = prevMonthLastDay - i;
        grid.appendChild(day);
    }
    
    const today = new Date().toDateString();
    for (let day = 1; day <= daysInMonth; day++) {
        const dayElement = document.createElement('div');
        const dateObj = new Date(year, month, day);
        const dateStr = dateObj.toDateString();
        const isToday = dateStr === today;
        
        dayElement.className = `calendar-day ${isToday ? 'today' : ''}`;
        dayElement.textContent = day;
        
        const dateKey = dateStr;
        if (appState.calendar[dateKey]) {
            dayElement.classList.add('has-activity');
            dayElement.title = `${appState.calendar[dateKey]} actividades`;
        }
        
        dayElement.onclick = () => {
            showToast(`📅 ${day} de ${monthNames[month]} - ${appState.calendar[dateKey] || 'Sin actividades'}`);
        };
        
        grid.appendChild(dayElement);
    }
    
    const totalCells = 42;
    const currentCells = grid.children.length;
    for (let i = currentCells; i < totalCells; i++) {
        const day = document.createElement('div');
        day.className = 'calendar-day other-month';
        day.textContent = i - currentCells + 1;
        grid.appendChild(day);
    }
}

function updateCalendarActivity() {
    const today = new Date().toDateString();
    if (!appState.calendar[today]) {
        appState.calendar[today] = 0;
    }
    appState.calendar[today] += 1;
    updateCalendar();
    saveProgress();
}

// ============================
// TEMPORIZADOR
// ============================
function initTimer() {
    const display = document.getElementById('timer-display');
    const progress = document.getElementById('timer-progress');
    const startBtn = document.getElementById('btn-start-timer');
    const pauseBtn = document.getElementById('btn-pause-timer');
    const resetBtn = document.getElementById('btn-reset-timer');
    
    if (!display) return;
    
    let time = appState.timer.time || 300;
    const totalTime = time;
    
    function updateDisplay() {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        display.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        progress.style.width = `${(time / totalTime) * 100}%`;
    }
    
    function startTimer() {
        if (appState.timer.interval) return;
        
        appState.timer.running = true;
        startBtn.classList.add('hidden');
        pauseBtn.classList.remove('hidden');
        
        appState.timer.interval = setInterval(() => {
            time--;
            appState.timer.time = time;
            updateDisplay();
            
            if (time <= 0) {
                clearInterval(appState.timer.interval);
                appState.timer.interval = null;
                appState.timer.running = false;
                startBtn.classList.remove('hidden');
                pauseBtn.classList.add('hidden');
                showToast('⏰ ¡Tiempo terminado!');
                speak('El tiempo ha terminado');
                giveReward('task');
                launchConfetti(10);
            }
        }, 1000);
    }
    
    function pauseTimer() {
        if (appState.timer.interval) {
            clearInterval(appState.timer.interval);
            appState.timer.interval = null;
            appState.timer.running = false;
            startBtn.classList.remove('hidden');
            pauseBtn.classList.add('hidden');
        }
    }
    
    function resetTimer() {
        if (appState.timer.interval) {
            clearInterval(appState.timer.interval);
            appState.timer.interval = null;
        }
        time = 300;
        appState.timer.time = 300;
        appState.timer.running = false;
        startBtn.classList.remove('hidden');
        pauseBtn.classList.add('hidden');
        updateDisplay();
    }
    
    if (startBtn) startBtn.onclick = startTimer;
    if (pauseBtn) pauseBtn.onclick = pauseTimer;
    if (resetBtn) resetBtn.onclick = resetTimer;
    
    updateDisplay();
}

// ============================
// GENERADOR DE REPORTES PDF
// ============================
function generateReport() {
    if (typeof window.jspdf === 'undefined') {
        showToast('❌ Error: Librería PDF no cargada');
        return;
    }
    
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    const user = appState.currentUser || { username: 'Alumno' };
    const totalTasks = appState.routines.length;
    const completedTasks = appState.routines.filter(t => t.done).length;
    const attempts = appState.stats.attempts || 0;
    const successes = appState.stats.successes || 0;
    const accuracy = attempts > 0 ? Math.round((successes / attempts) * 100) : 0;
    
    doc.setFontSize(24);
    doc.setTextColor(59, 130, 246);
    doc.text('OPENMIND', 20, 30);
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text('Reporte de Progreso', 20, 42);
    
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text(`Usuario: ${user.username}`, 20, 58);
    doc.text(`Fecha: ${new Date().toLocaleDateString()}`, 20, 66);
    doc.text(`Hora: ${new Date().toLocaleTimeString()}`, 20, 74);
    
    doc.line(20, 80, 190, 80);
    
    doc.setFontSize(14);
    doc.setTextColor(59, 130, 246);
    doc.text('📊 Estadísticas Generales', 20, 94);
    
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text(`• Tareas completadas: ${completedTasks}/${totalTasks} (${totalTasks > 0 ? Math.round((completedTasks/totalTasks)*100) : 0}%)`, 20, 108);
    doc.text(`• Intentos en juegos: ${attempts}`, 20, 118);
    doc.text(`• Aciertos: ${successes}`, 20, 128);
    doc.text(`• Precisión: ${accuracy}%`, 20, 138);
    
    doc.setFontSize(14);
    doc.setTextColor(59, 130, 246);
    doc.text('🏆 Logros y Recompensas', 20, 156);
    
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.text(`• Estrellas: ${appState.rewards.stars || 0}`, 20, 170);
    doc.text(`• Medallas: ${appState.rewards.badges.length || 0}`, 20, 180);
    doc.text(`• Racha: ${appState.rewards.streak || 0} días`, 20, 190);
    
    if (appState.rewards.badges.length > 0) {
        doc.setFontSize(12);
        doc.text('Medallas ganadas:', 20, 204);
        appState.rewards.badges.forEach((badgeId, index) => {
            const badge = BADGE_DEFINITIONS.find(b => b.id === badgeId);
            const label = badge ? badge.label : badgeId;
            doc.text(`  ${index + 1}. ${label}`, 25, 214 + (index * 8));
        });
    }
    
    doc.setFontSize(8);
    doc.setTextColor(100, 100, 100);
    doc.text('Reporte generado por OPENMIND - Plataforma de Apoyo para Alumnos con TEA', 20, 280);
    doc.text('© 2026 - Proyecto de Residencia Profesional', 20, 288);
    
    doc.save(`reporte-openmind-${user.username}-${new Date().toISOString().split('T')[0]}.pdf`);
    showToast('📄 Reporte PDF generado exitosamente');
}

// ============================
// MODO DOCENTE - PICTOGRAMAS
// ============================
function renderTeacherPictoList() {
    const container = document.getElementById('teacher-picto-list');
    if (!container) return;
    container.innerHTML = '';
    
    const customPictos = appState.pictograms.filter(p => p.isCustom);
    if (customPictos.length === 0) {
        container.innerHTML = '<p class="text-xs text-slate-400 italic">No hay pictogramas personalizados</p>';
        return;
    }
    
    customPictos.forEach(picto => {
        const item = document.createElement('div');
        item.className = "flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-xl text-sm";
        item.innerHTML = `
            <div class="flex items-center gap-2">
                <span class="text-2xl">${picto.emoji}</span>
                <span class="font-bold text-slate-700">${picto.label}</span>
                <span class="text-xs text-slate-400">${picto.category}</span>
            </div>
            <div class="flex gap-1">
                <button onclick="window.editPicto('${picto.id}')" class="p-1 hover:bg-blue-100 text-blue-600 rounded">
                    <i data-lucide="edit" class="w-4 h-4"></i>
                </button>
                <button onclick="window.deletePicto('${picto.id}')" class="p-1 hover:bg-red-100 text-red-600 rounded">
                    <i data-lucide="trash-2" class="w-4 h-4"></i>
                </button>
            </div>
        `;
        container.appendChild(item);
    });
    
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
}

function deletePicto(id) {
    showConfirm('Eliminar pictograma', '¿Estás seguro de eliminar este pictograma?', () => {
        appState.pictograms = appState.pictograms.filter(p => p.id !== id);
        renderPictograms();
        saveProgress();
        showToast('🗑️ Pictograma eliminado');
    });
}

function editPicto(id) {
    const picto = appState.pictograms.find(p => p.id === id);
    if (!picto) return;
    
    document.getElementById('teacher-picto-emoji').value = picto.emoji;
    document.getElementById('teacher-picto-label').value = picto.label;
    document.getElementById('teacher-picto-speech').value = picto.speech;
    document.getElementById('teacher-picto-category').value = picto.category;
    
    const form = document.getElementById('form-new-picto');
    form.dataset.editId = id;
    form.querySelector('button[type="submit"]').textContent = 'Actualizar Pictograma';
    form.querySelector('button[type="submit"]').className = 'w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-sm transition';
    
    showToast('✏️ Editando pictograma...');
}

// ============================
// MODAL DE CONFIRMACIÓN
// ============================
function showConfirm(title, message, callback) {
    const modal = document.getElementById('confirm-modal');
    const titleEl = document.getElementById('confirm-title');
    const messageEl = document.getElementById('confirm-message');
    const acceptBtn = document.getElementById('confirm-accept');
    const cancelBtn = document.getElementById('confirm-cancel');
    
    if (!modal) return;
    
    titleEl.textContent = title;
    messageEl.textContent = message;
    confirmCallback = callback;
    
    modal.classList.remove('hidden');
    
    acceptBtn.onclick = () => {
        modal.classList.add('hidden');
        if (confirmCallback) confirmCallback();
        confirmCallback = null;
    };
    
    cancelBtn.onclick = () => {
        modal.classList.add('hidden');
        confirmCallback = null;
    };
}

// ============================
// SISTEMA DE AYUDA
// ============================
function showHelp(tab, force = false) {
    if (!force && helpShownThisSession) return;
    
    const modal = document.getElementById('help-modal');
    const content = document.getElementById('help-content');
    if (!modal || !content) return;
    
    const helpContent = {
        speech: `
            <p class="font-bold text-blue-600">🗣️ Tablero de Comunicación</p>
            <p class="mt-2">Toca los pictogramas para construir frases.</p>
            <p>Puedes seleccionar varias tarjetas para formar oraciones completas.</p>
            <p>Usa el botón 🔊 para escuchar la frase completa.</p>
            <p class="text-sm text-slate-500 mt-2">💡 También puedes filtrar por categorías.</p>
        `,
        routine: `
            <p class="font-bold text-emerald-600">📋 Agenda Visual</p>
            <p class="mt-2">Sigue los pasos en orden para completar tu día.</p>
            <p>Toca cada tarea para marcarla como completada.</p>
            <p>El temporizador te ayuda a gestionar el tiempo.</p>
            <p class="text-sm text-slate-500 mt-2">💡 Completa todas las tareas para ganar una medalla especial.</p>
        `,
        game: `
            <p class="font-bold text-amber-600">🎮 Juego de Asociación</p>
            <p class="mt-2">Observa la imagen y selecciona la palabra correcta.</p>
            <p>Puedes cambiar la dificultad entre Fácil, Medio y Difícil.</p>
            <p>¡Gana 5 juegos seguidos para conseguir una medalla!</p>
            <p class="text-sm text-slate-500 mt-2">💡 Cada acierto te da una estrella.</p>
        `,
        progress: `
            <p class="font-bold text-purple-600">📊 Panel de Progreso</p>
            <p class="mt-2">Visualiza tu avance y logros obtenidos.</p>
            <p>Las estrellas y medallas son recompensas por tu esfuerzo.</p>
            <p>Genera un reporte PDF para compartir tu progreso.</p>
            <p class="text-sm text-slate-500 mt-2">💡 La racha se mantiene usando la app diariamente.</p>
        `,
        calendar: `
            <p class="font-bold text-cyan-600">📅 Calendario</p>
            <p class="mt-2">Visualiza tus actividades y logros en el calendario.</p>
            <p>Los días con actividades se muestran en azul.</p>
            <p class="text-sm text-slate-500 mt-2">💡 Toca un día para ver las actividades realizadas.</p>
        `
    };
    
    content.innerHTML = helpContent[tab] || helpContent.speech;
    modal.classList.remove('hidden');
    helpShownThisSession = true;
}

function closeHelp() {
    document.getElementById('help-modal').classList.add('hidden');
}

// ============================
// NOTIFICACIONES TOAST
// ============================
function showToast(message, duration = 3000) {
    const toast = document.getElementById('toast-message');
    const text = document.getElementById('toast-text');
    if(!toast || !text) return;
    
    text.innerText = message;
    toast.classList.remove('translate-y-24', 'opacity-0');
    toast.classList.add('translate-y-0', 'opacity-100', 'pointer-events-auto');

    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
        toast.classList.remove('translate-y-0', 'opacity-100', 'pointer-events-auto');
        toast.classList.add('translate-y-24', 'opacity-0');
    }, duration);
}

// ============================
// CAMBIO DE VISTAS
// ============================
function switchTab(activeTab) {
    const tabs = ['speech', 'routine', 'game', 'progress', 'calendar'];
    tabs.forEach(t => {
        const btn = document.getElementById(`tab-${t}`);
        const view = document.getElementById(`view-${t}`);
        if (t === activeTab) {
            if(btn) {
                btn.className = "flex-grow flex items-center justify-center gap-2 py-3 px-4 bg-white border-2 border-blue-500 text-blue-700 font-bold rounded-2xl shadow-sm transition-all text-sm sm:text-base";
            }
            if(view) view.classList.remove('hidden');
        } else {
            if(btn) btn.className = "flex-grow flex items-center justify-center gap-2 py-3 px-4 bg-white border-2 border-transparent text-slate-600 font-bold rounded-2xl hover:bg-white/80 transition-all text-sm sm:text-base";
            if(view) view.classList.add('hidden');
        }
    });
    appState.currentTab = activeTab;
}

// ============================
// MODO OSCURO
// ============================
function toggleDarkMode() {
    appState.darkMode = !appState.darkMode;
    document.body.classList.toggle('dark-mode');
    const icon = document.querySelector('#btn-dark-mode i');
    if (icon) {
        icon.setAttribute('data-lucide', appState.darkMode ? 'sun' : 'moon');
        if (typeof lucide !== 'undefined' && lucide.createIcons) {
            lucide.createIcons();
        }
    }
    showToast(appState.darkMode ? '🌙 Modo oscuro activado' : '☀️ Modo claro activado');
}

// ============================
// BLOQUEO DE PANTALLA
// ============================
function toggleLock() {
    appState.isLocked = !appState.isLocked;
    const lockBtn = document.getElementById('btn-lock');
    const icon = lockBtn?.querySelector('i');
    
    if (appState.isLocked) {
        document.querySelector('main').classList.add('opacity-50', 'pointer-events-none');
        document.querySelectorAll('nav button, #user-header button, #btn-logout').forEach(el => {
            el.classList.add('opacity-50');
        });
        if (icon) icon.setAttribute('data-lucide', 'unlock');
        showToast('🔒 App bloqueada');
    } else {
        document.querySelector('main').classList.remove('opacity-50', 'pointer-events-none');
        document.querySelectorAll('nav button, #user-header button, #btn-logout').forEach(el => {
            el.classList.remove('opacity-50');
        });
        if (icon) icon.setAttribute('data-lucide', 'lock');
        showToast('🔓 App desbloqueada');
    }
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
}

// ============================
// EMERGENCIA
// ============================
function triggerEmergency() {
    const modal = document.getElementById('emergency-modal');
    modal.classList.remove('hidden');
    speak('¡Ayuda! Necesito asistencia, por favor');
    showToast('🆘 ¡ALERTA DE EMERGENCIA ENVIADA!');
}

function closeEmergency() {
    document.getElementById('emergency-modal').classList.add('hidden');
}

// ============================
// CONFIGURACIÓN DE EVENTOS
// ============================
function setupEventListeners() {
    // Emergencia
    const emergencyBtn = document.getElementById('btn-emergency');
    if (emergencyBtn) emergencyBtn.onclick = triggerEmergency;
    
    const emergencyClose = document.getElementById('emergency-close');
    if (emergencyClose) emergencyClose.onclick = closeEmergency;
    
    const emergencySpeak = document.getElementById('emergency-speak');
    if (emergencySpeak) {
        emergencySpeak.onclick = () => speak('¡Ayuda! Necesito asistencia, por favor');
    }
    
    // Bloqueo
    const lockBtn = document.getElementById('btn-lock');
    if (lockBtn) lockBtn.onclick = toggleLock;
    
    // Cambio de modo
    const modeChild = document.getElementById('btn-mode-child');
    const modeTeacher = document.getElementById('btn-mode-teacher');
    const navStudent = document.getElementById('nav-student');
    const viewTeacher = document.getElementById('view-teacher');
    
    if (modeChild) {
        modeChild.onclick = () => {
            appState.role = 'child';
            modeChild.className = "px-3 py-1.5 rounded-md bg-white text-blue-600 shadow-sm transition-all";
            modeTeacher.className = "px-3 py-1.5 rounded-md text-slate-600 hover:text-slate-900 transition-all";
            if (navStudent) navStudent.classList.remove('hidden');
            switchTab(appState.currentTab);
            if (viewTeacher) viewTeacher.classList.add('hidden');
            speak("Modo Alumno activado");
        };
    }
    
    if (modeTeacher) {
        modeTeacher.onclick = () => {
            appState.role = 'teacher';
            modeTeacher.className = "px-3 py-1.5 rounded-md bg-white text-blue-600 shadow-sm transition-all";
            modeChild.className = "px-3 py-1.5 rounded-md text-slate-600 hover:text-slate-900 transition-all";
            if (navStudent) navStudent.classList.add('hidden');
            
            document.querySelectorAll('#view-speech, #view-routine, #view-game, #view-progress, #view-calendar').forEach(el => {
                if (el) el.classList.add('hidden');
            });
            if (viewTeacher) viewTeacher.classList.remove('hidden');
            speak("Modo Docente activado");
            updateStatsUI();
            renderTeacherPictoList();
        };
    }
    
    // Tabs
    ['speech', 'routine', 'game', 'progress', 'calendar'].forEach(tab => {
        const el = document.getElementById(`tab-${tab}`);
        if(el) {
            el.onclick = () => {
                if (appState.isLocked) {
                    showToast('🔒 Desbloquea la app primero');
                    return;
                }
                appState.currentTab = tab;
                switchTab(tab);
            };
        }
    });
    
    // Frases
    const speakBtn = document.getElementById('btn-speak-phrase');
    if (speakBtn) speakBtn.onclick = speakPhrase;
    
    const clearBtn = document.getElementById('btn-clear-phrase');
    if (clearBtn) clearBtn.onclick = clearPhrase;
    
    // Filtros de categoría
    setupCategoryFilters();
    
    // Formulario nuevo pictograma
    const formNewPicto = document.getElementById('form-new-picto');
    if (formNewPicto) {
        formNewPicto.onsubmit = (e) => {
            e.preventDefault();
            const emoji = document.getElementById('teacher-picto-emoji').value.trim();
            const label = document.getElementById('teacher-picto-label').value.trim();
            const speech = document.getElementById('teacher-picto-speech').value.trim();
            const category = document.getElementById('teacher-picto-category').value;
            const imageFile = document.getElementById('teacher-picto-image').files[0];
            
            if(!emoji || !label || !speech) {
                showToast("Por favor completa todos los campos del pictograma.");
                return;
            }
            
            const editId = formNewPicto.dataset.editId;
            
            if (editId) {
                const index = appState.pictograms.findIndex(p => p.id === editId);
                if (index !== -1) {
                    appState.pictograms[index] = {
                        ...appState.pictograms[index],
                        emoji,
                        label,
                        speech,
                        category
                    };
                    showToast("✅ Pictograma actualizado.");
                }
                delete formNewPicto.dataset.editId;
                formNewPicto.querySelector('button[type="submit"]').textContent = 'Agregar al Tablero';
                formNewPicto.querySelector('button[type="submit"]').className = 'w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-xl text-sm transition';
            } else {
                const newPicto = {
                    id: 'p_custom_' + Date.now(),
                    emoji,
                    label,
                    speech,
                    category,
                    isCustom: true
                };
                
                if (imageFile) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                        newPicto.imageData = event.target.result;
                        appState.pictograms.push(newPicto);
                        renderPictograms();
                        saveProgress();
                        showToast("✅ Pictograma agregado con imagen.");
                    };
                    reader.readAsDataURL(imageFile);
                } else {
                    appState.pictograms.push(newPicto);
                    renderPictograms();
                    saveProgress();
                    showToast("✅ Pictograma agregado al tablero.");
                }
            }
            
            formNewPicto.reset();
            document.getElementById('teacher-picto-image').value = '';
            renderPictograms();
            saveProgress();
        };
    }
    
    // Configuración de voz
    const voiceRate = document.getElementById('voice-rate');
    if (voiceRate) {
        voiceRate.oninput = (e) => {
            appState.voiceRate = parseFloat(e.target.value);
            document.getElementById('voice-rate-val').innerText = appState.voiceRate + 'x';
        };
    }
    
    const voicePitch = document.getElementById('voice-pitch');
    if (voicePitch) {
        voicePitch.oninput = (e) => {
            appState.voicePitch = parseFloat(e.target.value);
            document.getElementById('voice-pitch-val').innerText = appState.voicePitch;
        };
    }
    
    const testVoice = document.getElementById('btn-test-voice');
    if (testVoice) {
        testVoice.onclick = () => {
            speak("Probando velocidad y tono del sintetizador de voz.");
        };
    }
    
    // Añadir tarea a rutina
    const addTaskBtn = document.getElementById('btn-add-task');
    if (addTaskBtn) {
        addTaskBtn.onclick = () => {
            const emoji = document.getElementById('teacher-task-emoji').value.trim() || '📝';
            const title = document.getElementById('teacher-task-title').value.trim();
            
            if (!title) {
                showToast("Por favor, ponle un título a la actividad.");
                return;
            }
            
            appState.routines.push({
                id: 'r_custom_' + Date.now(),
                emoji,
                title,
                done: false,
                isCustom: true
            });
            
            renderRoutines();
            renderTeacherRoutines();
            document.getElementById('teacher-task-emoji').value = '';
            document.getElementById('teacher-task-title').value = '';
            showToast("✅ Nueva rutina de tareas agregada.");
            saveProgress();
        };
    }
    
    // Resetear estadísticas
    const resetStats = document.getElementById('btn-reset-stats');
    if (resetStats) {
        resetStats.onclick = () => {
            showConfirm('Reiniciar estadísticas', '¿Estás seguro de reiniciar todas las estadísticas?', () => {
                appState.stats = { attempts: 0, successes: 0 };
                appState.gameWinsStreak = 0;
                updateStatsUI();
                updateProgressUI();
                saveProgress();
                showToast("📊 Métricas reiniciadas.");
            });
        };
    }
    
    // Restaurar de fábrica
    const restoreApp = document.getElementById('btn-restore-app');
    if (restoreApp) {
        restoreApp.onclick = () => {
            showConfirm('Restaurar aplicación', '¿Estás seguro de restaurar el estado original? Se perderán los datos personalizados.', () => {
                appState.pictograms = [...DEFAULT_PICTOGRAMS];
                appState.routines = [...DEFAULT_ROUTINES];
                appState.stats = { attempts: 0, successes: 0 };
                appState.rewards = { stars: 0, badges: [], streak: 0, lastActivity: null };
                appState.gameWinsStreak = 0;
                appState.calendar = {};
                renderAll();
                saveProgress();
                showToast("🔄 Restauración completada.");
            });
        };
    }
    
    // Modo oscuro
    const darkModeBtn = document.getElementById('btn-dark-mode');
    if (darkModeBtn) darkModeBtn.onclick = toggleDarkMode;
    
    // Botones de calendario
    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();
    
    const prevMonth = document.getElementById('prev-month');
    const nextMonth = document.getElementById('next-month');
    
    if (prevMonth) {
        prevMonth.onclick = () => {
            if (currentMonth === 0) {
                currentMonth = 11;
                currentYear--;
            } else {
                currentMonth--;
            }
            renderCalendarMonth(currentMonth, currentYear);
        };
    }
    
    if (nextMonth) {
        nextMonth.onclick = () => {
            if (currentMonth === 11) {
                currentMonth = 0;
                currentYear++;
            } else {
                currentMonth++;
            }
            renderCalendarMonth(currentMonth, currentYear);
        };
    }
    
    // Generar reporte PDF
    const generateReportBtn = document.getElementById('btn-generate-report');
    if (generateReportBtn) generateReportBtn.onclick = generateReport;
    
    // Ayuda
    const helpBtn = document.getElementById('btn-help');
    if (helpBtn) {
        helpBtn.onclick = () => showHelp(appState.currentTab, true);
    }
    
    const closeHelpBtn = document.getElementById('close-help');
    if (closeHelpBtn) closeHelpBtn.onclick = closeHelp;
    
    const helpModal = document.getElementById('help-modal');
    if (helpModal) {
        helpModal.onclick = (e) => {
            if (e.target === e.currentTarget) closeHelp();
        };
    }
    
    // Cerrar modales con Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeHelp();
            document.getElementById('emergency-modal').classList.add('hidden');
            document.getElementById('confirm-modal').classList.add('hidden');
        }
    });
    
    // Eventos de Login (se llaman después de setup para asegurar que los elementos existen)
    setupLoginEvents();
}

// ============================
// RENDERIZADO COMPLETO
// ============================
function renderAll() {
    renderPictograms();
    renderRoutines();
    renderTeacherRoutines();
    updateStatsUI();
    updateProgressUI();
    updateCalendar();
    initGame();
    updateHeaderStars();
}

// ============================
// EXPONER FUNCIONES GLOBALMENTE PARA ONCLICK
// ============================
window.moveTask = moveTask;
window.deleteTask = deleteTask;
window.editPicto = editPicto;
window.deletePicto = deletePicto;

// ============================
// INICIALIZACIÓN EXTRA
// ============================
setInterval(() => {
    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
}, 1000);